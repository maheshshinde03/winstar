import { Injectable } from '@angular/core';
import firebase from "firebase/app";
import "firebase/firestore";
import "firebase/auth";

import { Router } from '@angular/router';


const config = {
  // apiKey: "AIzaSyAjN6jqtpHjrLs_lbwCEWhCciIG5gXD20c",
  // authDomain: "chat-support-88c39.firebaseapp.com",
  // projectId: "chat-support-88c39",
  // storageBucket: "chat-support-88c39.appspot.com",
  // messagingSenderId: "352459585353",
  // appId: "1:352459585353:web:4d1ddce2f95e7e5eda8c98",
  // measurementId: "G-2DC1DE85CP"

  apiKey: "AIzaSyASJAecflcb2JkmfsbPxQ_07Y7cD4ZBRHo",
  authDomain: "gamechat-4620e.firebaseapp.com",
  projectId: "gamechat-4620e",
  //databaseURL: "https://gamechat-4620e-default-rtdb.firebaseio.com",
  storageBucket: "gamechat-4620e.appspot.com",
  messagingSenderId: "117842335837",
  appId: "1:117842335837:web:9294130ee988d497de55b4",
  measurementId: "G-F1WC3DB1PX"

}; 

@Injectable({
  providedIn: 'root'
})
export class FirebaseService {
  loader: boolean = false;
  user: any;
  db: any;
  admin: boolean = false;

  constructor(private router: Router) { }

  configApp() {
    firebase.initializeApp(config);
    this.db = firebase.firestore();//firebase.database();
  }


  signUp({first_name, email, password }) {
    console.log(first_name);
    var franchiseId = 'Fid-02'
    firebase.auth().createUserWithEmailAndPassword(email, password)
    .then((user)=>{
      this.loader = false;

      this.user = {
        name: first_name,
        id: email.substring(0, email.indexOf('@')).toLowerCase()
      };
      localStorage.setItem('loggedIn', this.user.id); 
      
      // create user list on firebase
      this.db.collection("users").doc(this.user.id).set({
        name: first_name,
        id: this.user.id
      });

      // this.router.navigate(['/chat/'], { queryParams: { name: 'Messenger', id: this.user.id }, skipLocationChange: false })
      console.log('register', user);
      console.log(this.user.id);

    })
    .catch((error)=> {
      // Handle Errors here.
      this.loader = false;
      console.log('error while signup', error);
      // ...
    });
  }


  addChatMessage(id: string, msg: string, type: string) {
    let key = this.generateRandomString(16);
    return this.db.collection("chatRoom/").doc(key).set({
          type: type,
          // from:this.user.id,
          id: id,
          key: key,
          msg: msg,
          timestamp: firebase.firestore.FieldValue.serverTimestamp()
    });
  }

  // sendMsg(id: string, msg: string, type: string) {
  //   let key = this.generateRandomString(16);
  //   this.db.collection("chatRoom/").doc(key).set({
  //         type: type,
  //         id: id,
  //         key: key,
  //         msg: msg,
  //         timestamp: firebase.firestore.FieldValue.serverTimestamp()
  //   });
    
  // }

  generateRandomString(length) {
    let text = "";
    let possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    for (let i = 0; i < length; i++){
      text += possible.charAt(Math.floor(Math.random() * possible.length));
    }
    return text;
  }
}
