import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AlertController,LoadingController } from '@ionic/angular';
import { Button } from 'protractor';
import { AuthenticationService } from 'src/app/services/authentication.service';

import { UserService } from '../../services/user.service'

import { FirebaseService } from 'src/app/services/firebase.service';

import  { User } from '../../interfaces/user';
import { UsernameValidator } from 'src/app/validator/username-validator';

@Component({
  selector: 'app-register',
  templateUrl: './register.page.html',
  styleUrls: ['./register.page.scss'],
})
export class RegisterPage implements OnInit {
  credentials: FormGroup;

  constructor(
    private fb:FormBuilder,
    private loadingController:LoadingController,
    private authService:AuthenticationService,
    private fire:FirebaseService,
    private alertCtrl:AlertController,
    private router:Router,
    private userService: UserService,
  ) { }

  ngOnInit() {
    let userValidator = new UsernameValidator(this.authService);
    this.credentials = this.fb.group({
      business_name:['',[Validators.required]],
      user_name:['',Validators.compose([Validators.required,Validators.maxLength(10)]), userValidator.checkUsername.bind(userValidator)],
      first_name:['',[Validators.required]],
      last_name:['',[Validators.required]],
      mobile:['',[Validators.required]],
      email:['',[Validators.required,Validators.email]],
      password:['',[Validators.required,Validators.minLength(6)]],
     
    });
     console.log(userValidator.checkUsername.bind(userValidator));

  }


  // async signUp() {
  //   this.fire.signUp(this.credentials.value);
  // }



  async register(){
    
    const loading = await this.loadingController.create();
    await loading.present();
    // this.signUp();
    this.authService.register(this.credentials.value).subscribe(
      async (res) =>{
        await loading.dismiss();
        const alert = await this.alertCtrl.create({
          header:'Success',
          message: 'Registration Successful',
          // message: res.error.error,
          buttons:['ok'],
        });
        await alert.present();
        this.router.navigateByUrl('/');
      }
    )
  }

  get business_name(){
    return this.credentials.get('business_name');
  }

  get user_name(){
    return this.credentials.get('user_name');
  }

  get first_name(){
    return this.credentials.get('first_name');
  }

  get last_name(){
    return this.credentials.get('last_name');
  }

  get mobile(){
    return this.credentials.get('mobile');
  }

  get email(){
    return this.credentials.get('email');
  }

  get password(){
    return this.credentials.get('password');
  }

  

}
