 import { Component, EventEmitter, Input, OnInit, Output ,ChangeDetectorRef} from '@angular/core';
 import { FormBuilder, FormGroup, Validators } from '@angular/forms';
 import { Router } from '@angular/router';
 import { ActionSheetController, ToastController, Platform, LoadingController, ModalController ,AlertController} from '@ionic/angular';
 import { Button } from 'protractor';
 import { from } from 'rxjs';
 import { AuthenticationService } from 'src/app/services/authentication.service';
 import { UserService } from '../../services/user.service'


 import { File, FileEntry } from '@ionic-native/File/ngx';
import { HttpClient } from '@angular/common/http';
import { WebView } from '@ionic-native/ionic-webview/ngx';
import { Storage } from '@ionic/storage';
import { FilePath } from '@ionic-native/file-path/ngx';

import { finalize } from 'rxjs/operators';
const STORAGE_KEY = 'my_images';

 import  { User } from '../../interfaces/user';
 import { Bank } from '../../interfaces/bank';
 import { Camera, CameraOptions ,PictureSourceType} from "@ionic-native/camera/ngx";
@Component({
  selector: 'app-profile',
  templateUrl: './profile.page.html',
  styleUrls: ['./profile.page.scss'],
})
export class ProfilePage implements OnInit {
  images = [];
  platform: any;

  segmentModel = "profile";
   users: User;
   banks: Bank;
   credentials: FormGroup;
   bankdetails: FormGroup;
   passworddetails: FormGroup;
  
   loop:any=[];
   userImg: any = '';
   user_id:any;
  public response: any;
  public base64Image: string;
  public fileImage: string;
  public responseData: any;
   userData = {imageB64: "",user_id:"" };

   gelleryOptions: CameraOptions = {
    quality: 100,
    sourceType: this.camera.PictureSourceType.PHOTOLIBRARY,
    destinationType: this.camera.DestinationType.DATA_URL,
    mediaType: this.camera.MediaType.PICTURE,
    allowEdit: true
    }
   constructor(
     private fb: FormBuilder,
     private camera: Camera,
     private file: File,
     private http: HttpClient, 
     private webview: WebView,
     private actionSheetController: ActionSheetController, 
     private toastController: ToastController,
     private storage: Storage, private plt: Platform, 
     private loadingController: LoadingController,
     private ref: ChangeDetectorRef, 
     private filePath: FilePath,
     private router: Router, 
     private authService:AuthenticationService,
     private alertCtrl:AlertController,
     public modalController: ModalController,
     private userService: UserService,
     ) { 
      this.userImg = '../assets/img/dog.jpg';
      // this.getImage();
     }  

     getImage(){
      this.authService.getuserImage().then(
        result=> {
          this.response = result;
          this.userImg = this.response.imageData;
          console.log(this.userImg);
        },
        err => {
          console.log("error");
          // Error log
        }
      );
    }

    pathForImage(img) {
      if (img === null) {
        return '';
      } else {
        let converted = this.webview.convertFileSrc(img);
        return converted;
      }
    }

    async presentToast(text) {
      const toast = await this.toastController.create({
          message: text,
          position: 'bottom',
          duration: 3000
      });
      toast.present();
    }

     // ---------------------------------Adding New Images----------------
  async selectImage() {
    const actionSheet = await this.actionSheetController.create({
        header: "Select Image source",
        buttons: [{
                text: 'Load from Library',
                handler: () => {
                    this.takePicture(this.camera.PictureSourceType.PHOTOLIBRARY);
                }
            },
            {
                text: 'Use Camera',
                handler: () => {
                    this.takePicture(this.camera.PictureSourceType.CAMERA);
                }
            },
            {
                text: 'Cancel',
                role: 'cancel'
            }
        ]
    });
    await actionSheet.present();
}
 
takePicture(sourceType: PictureSourceType) {
    var options: CameraOptions = {
        quality: 100,
        sourceType: sourceType,
        saveToPhotoAlbum: true,
        correctOrientation: true
    };
 
    this.camera.getPicture(options).then(imagePath => {
        if (this.plt.is('android') && sourceType === this.camera.PictureSourceType.PHOTOLIBRARY) {
          // this.storeimage(imagePath)
                this.filePath.resolveNativePath(imagePath)
                    .then(filePath => {
                    let correctPath = filePath.substr(0, filePath.lastIndexOf('/') + 1);
                    let currentName = imagePath.substring(imagePath.lastIndexOf('/') + 1, imagePath.lastIndexOf('?'));
                    this.copyFileToLocalDir(correctPath, currentName, this.createFileName());
                    console.log(imagePath);
                    
                });
        } else {
          // this.storeimage(imagePath)
            var currentName = imagePath.substr(imagePath.lastIndexOf('/') + 1);
            var correctPath = imagePath.substr(0, imagePath.lastIndexOf('/') + 1);
            this.copyFileToLocalDir(correctPath, currentName, this.createFileName());
            this.authService.uploadImage(imagePath).then(res => {
              console.log(res);
              })
            console.log(imagePath);
        }
    });
 
}

//-----------------Copy Files & Store Local Reference
createFileName() {
  var d = new Date(),
      n = d.getTime(),
      newFileName = n + ".jpg";
  return newFileName;
}

copyFileToLocalDir(namePath, currentName, newFileName) {
  this.file.copyFile(namePath, currentName, this.file.dataDirectory, newFileName).then(success => {
      // this.updateStoredImages(newFileName);
      // this.storeimage(newFileName);

      
  }, error => {
    console.log(error);
      this.presentToast('Error while storing file.');
  });
}

// storeimage(imagePath){
//   var id = 456

//   this.userService.uploadImage(imagePath, id).then(res => {
//   console.log(res);
//   })

// }

//---------------Upload Files with POST and Form Data

startUpload(imgEntry) {
  console.log(imgEntry);
  this.file.resolveLocalFilesystemUrl(imgEntry.filePath)
      .then(entry => {
          ( < FileEntry > entry).file(file => this.readFile(file))
      })
      .catch(err => {
          this.presentToast('Error while reading file.');
      });
}

readFile(file: any) {
  const reader = new FileReader();
  reader.onload = () => {
      const formData = new FormData();
      const imgBlob = new Blob([reader.result], {
          type: file.type
      });
      formData.append('file', imgBlob, file.name);
      this.uploadImageData(formData);
  };
  reader.readAsArrayBuffer(file);
}

async uploadImageData(formData: FormData) {
  const loading = await this.loadingController.create({
      message: 'Uploading image...',
  });
  await loading.present();

  const baseUrl = 'http://localhost:3000';
  this.http.post(`${baseUrl}/img/`,formData)
      .pipe(
          finalize(() => {
              loading.dismiss();
          })
      )
      .subscribe(res => {
          if (res['success']) {
              this.presentToast('File upload complete.')
          } else {
              this.presentToast('File upload failed.')
          }
      });
}



    //  takePhoto() {
    //   console.log("coming here");
  
    //   const options: CameraOptions = {
    //     quality: 100,
    //     sourceType: this.camera.PictureSourceType.PHOTOLIBRARY,
    //     destinationType: this.camera.DestinationType.DATA_URL,
    //     encodingType: this.camera.EncodingType.JPEG,
    //     mediaType: this.camera.MediaType.PICTURE,
    //     saveToPhotoAlbum: true,
    //     correctOrientation: true
    //   };
  
    //   this.camera.getPicture(options).then(
    //     imageData => {
    //       this.base64Image = "data:image/jpeg;base64," + imageData;
    //       console.log(this.base64Image);
    //       // this.userImg = this.base64Image
    //       this.sendData(imageData);
    //     },
    //     err => {
    //       console.log(err);
    //     }
    //   );
    // }

    sendData(imageData) {
      this.userData.imageB64 = imageData;
      this.userData.user_id = "1";
      // this.userData.token = "222";
      console.log(this.userData);
      this.authService.UsersetImage(this.userData).then(
        result => {
          this.responseData = result;
        },
        err => {
          // Error log
        }
      );
    }

      async ngOnInit() {
       this.credentials = this.fb.group({         
         business_name:['',[Validators.required]],
         first_name:['',[Validators.required]],
         last_name:['',[Validators.required]],
         mobile:['',[Validators.required]],
         alt_mobile:[''],
         email:['',[Validators.required,Validators.email]],
         business_category:['',[Validators.required]],
         business_address:['',[Validators.required]],
         city:['',[Validators.required]],
         pin_code:['',[Validators.required]],
         landmark:['',[Validators.required]],
        // password:['',[Validators.required]],
       
       });

       this.bankdetails = this.fb.group({         
        account_name:['',[Validators.required]],
        account_no:['',[Validators.required]],
        bank_name:['',[Validators.required]],
        ifsc_code:['',[Validators.required]],
        branch_name:['',[Validators.required]],
        bank_city:['',[Validators.required]],
        account_type:['',[Validators.required]]
      
      });

      this.passworddetails = this.fb.group({         
        change_pass:['',[Validators.required]]      
      });

       (await this.authService.getUser()).subscribe(response =>{
        this.users = response
        console.log(response);
       }),
    
      (await this.authService.getbankdetails()).subscribe(data =>{
      this.banks = data
      //console.log(data);
      })
  
    }


    get business_name(){
      return this.credentials.get('business_name');
    }
  
    get first_name(){
      return this.credentials.get('first_name');
    }
  
    get last_name(){
      return this.credentials.get('last_name');
    }
  
    get mobile(){
      return this.credentials.get('mobile');
    }
  
    get landmark(){
      return this.credentials.get('landmark');
    }
  
  
    get business_category(){
      return this.credentials.get('business_category');
    }

    get business_address(){
      return this.credentials.get('business_address');
    }

    get city(){
       return this.credentials.get('city');
     }

    get pin_code(){
      return this.credentials.get('pin_code');
    }

    get email(){
      return this.credentials.get('email');
    }

    get account_name(){
      return this.bankdetails.get('account_name');
    } 

    get account_no(){
      return this.bankdetails.get('account_no');
    } 

    get bank_name(){
      return this.bankdetails.get('bank_name');
    } 

    get ifsc_code(){
      return this.bankdetails.get('ifsc_code');
    } 

    get branch_name(){
      return this.bankdetails.get('branch_name');
    } 

    get bank_city(){
      return this.bankdetails.get('bank_city');
    } 

    get account_type(){
      return this.bankdetails.get('account_type');
    } 

    get change_pass(){
      return this.passworddetails.get('change_pass');
    }

  async profileUpdate(){
    const loading = await this.loadingController.create();
    await loading.present();

    (await this.authService.update_user(this.credentials.value)).subscribe(
      async (res) =>{
        await loading.dismiss();
        const alert = await this.alertCtrl.create({
          header:'Success',
          message: 'Information updated Successfully',
          // message: res.error.error,
          buttons:['ok'],
        });
        await alert.present();
        this.router.navigateByUrl('/tabs-menu/profile');
      }
    )
  }

  async changePass(){
    const loading = await this.loadingController.create();
    await loading.present();

    (await this.authService.change_password(this.passworddetails.value)).subscribe(
      async (res) =>{
        await loading.dismiss();
        const alert = await this.alertCtrl.create({
          header:'Success',
          message: 'Password change Successfully',
          // message: res.error.error,
          buttons:['ok'],
        });
        await alert.present();
        this.router.navigateByUrl('/tabs-menu/profile');
      }
    )
  }

  async bankUpdate(){
    const loading = await this.loadingController.create();
    await loading.present();

    (await this.authService.update_bank(this.bankdetails.value)).subscribe(
      async (res) =>{
        await loading.dismiss();
        const alert = await this.alertCtrl.create({
          header:'Success',
          message: 'Information updated Successfully',
          // message: res.error.error,
          buttons:['ok'],
        });
        await alert.present();
        this.router.navigateByUrl('/tabs-menu/profile');
      }
    )
  }





}


