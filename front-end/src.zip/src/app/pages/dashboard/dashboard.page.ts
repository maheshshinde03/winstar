import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from 'src/app/services/authentication.service';

import { UserService } from '../../services/user.service'

import { User } from '../../interfaces/user';
import { Game } from '../../interfaces/game'

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.page.html',
  styleUrls: ['./dashboard.page.scss'],
})
export class DashboardPage implements OnInit {

  users: User;
  games: Game;
  games1: Game;
  frangames: Game;

  constructor(
    private authService:AuthenticationService,
    private userService: UserService,
    private router: Router
  ) { }

  async ngOnInit() {
    

}

  async ionViewWillEnter() {
  (await this.authService.getUser()).subscribe(response =>{
    this.users = response
    //console.log(Response);
});


(await this.authService.last_win_game_details()).subscribe(response =>{
  console.log(response);
  this.games = response
  //console.log(Response);
});

(await this.authService.fran_last_win_game_details()).subscribe(response =>{
  console.log(response);
  this.frangames = response
  //console.log(Response);
});
}
}
