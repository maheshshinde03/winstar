import { Component, OnInit } from '@angular/core';
import { AuthenticationService} from 'src/app/services/authentication.service';
import { Notifications } from '../../interfaces/notifications';
import  { User } from '../../interfaces/user';
import { AlertController } from '@ionic/angular';

import { UserService } from '../../services/user.service'

@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.page.html',
  styleUrls: ['./notifications.page.scss'],
})
export class NotificationsPage implements OnInit {
  yesterday: Date = new Date();
  today: Date = new Date();
  tomorrow: Date = new Date();
  
  notifications : Notifications;
  users: User;
  constructor(private authService: AuthenticationService,
    public alertController: AlertController,
    private userService: UserService,) { }

  async ngOnInit() {
    console.log(this.notifications);
    
    
                          //   (await this.authService.getUser()).subscribe(response =>{
                          //     this.users = response
                          //       //console.log(response);
                          //     }),
                          //   setInterval(async ()=>{
                          //   (await this.authService.get_notifications()).subscribe(response =>{
                          //     this.notifications = response
                          //       //console.log(response);
                          //     })
                          // }, 4000);
  }

  async ionViewWillEnter(){
    this.yesterday.setDate(this.yesterday.getDate() - 1);
    (await this.authService.getUser()).subscribe(response =>{
          this.users = response
            //console.log(response);
          }),

          (await this.authService.get_notifications()).subscribe(response =>{
                this.notifications = response
                  console.log(response);
                })
  }


  getFormatedTime(dateString){
    var date = new Date(dateString);
    var hours = date.getHours() > 12 ? date.getHours() - 12 : date.getHours();
    var am_pm = date.getHours() >= 12 ? "pm" : "am";
    var minutes = date.getMinutes() < 10 ? "0" + date.getMinutes() : date.getMinutes();
    let time = hours + ":" + minutes + " " + am_pm;
    return time;
 }
}
