import { Component, OnInit } from '@angular/core';
// import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';


import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { LoadingController, ModalController, NavController, NavParams } from '@ionic/angular';
 import { AlertController } from '@ionic/angular';
 import { NgForm } from '@angular/forms';
//import { ControllerPage } from '../controller/controller.page';
import { PointsModalPage } from '../points-modal/points-modal.page';
import { AuthenticationService } from 'src/app/services/authentication.service';

import * as moment from 'moment';


@Component({
  selector: 'app-newgame',
  templateUrl: './newgame.page.html',
  styleUrls: ['./newgame.page.scss'],
})
export class NewgamePage implements OnInit {
  
  date: any = new Date().toISOString();
  //today: Date = new Date();
  today= moment(new Date()).format("YYYY-MM-DD HH:mm:ss");
  game_points: FormGroup;
  users:any;
  gameids:any;
  gameimgs:any;
  

  ngOnInit() {
    this.game_points = this.fb.group({

      img_1:['',[Validators.required]],
      img_2:['',[Validators.required]],
      img_3:['',[Validators.required]],
      img_4:['',[Validators.required]],
      img_5:['',[Validators.required]],
      img_6:['',[Validators.required]],
      img_7:['',[Validators.required]],
      img_8:['',[Validators.required]],
      img_9:['',[Validators.required]],
      img_10:['',[Validators.required]],
      img_11:['',[Validators.required]],
      // img_0:['',[Validators.required]],
      fran_id:['',[Validators.required]],
      game_id:['',[Validators.required]],
      total:['',[Validators.required]],
      date_time:[ this.today ],

      
     
    });
  }

  data1=0;
  data2=0;
  data3=0;
  data4=0;
  data5=0;
  data6=0;
  data7=0;
  data8=0;
  data9=0;
  data10=0;
  data11=0;
  // data0=0;
  total:number;
 
  data:any;
  no:any;


  constructor(
    private fb:FormBuilder,
    private loadingController:LoadingController,
    private alertCtrl:AlertController,
    private modalController: ModalController,
    private auth:AuthenticationService,
    private navCtrl:NavController,
    public router:Router,
    ) {  
    console.log(this.today) ;
    
  }

  onInput($event:any) {
    let theEvent = $event || window.event,
        key = theEvent.target.value,
        regex = /[0-9]+/g
    if( !regex.test(key) ) {
      let resp = $event.target.value.match(regex)
      $event.target.value = resp ? resp.join('')  : ''
    }
   }

  async ionViewWillEnter() {
    (await this.auth.getUser()).subscribe(response =>{
      this.users = response
      //console.log(Response);
  });

  (await this.auth.current_game_id()).subscribe(response =>{
    this.gameids = response
    //console.log(Response);
});

(await this.auth.get_current_gameImg_amount()).subscribe(response =>{
  this.gameimgs = response
  console.log(response);
});

}

  async modals1(response){
    const modal = await this.modalController.create({
      component:  PointsModalPage,
      cssClass: 'my-custom-class', 
      componentProps: {
        response: response,
        'model_title': "Elephant",
        'image_no':'1',
        'pre_points' : this.data1
      }
    });
    
    modal.onDidDismiss()
      .then((data) => {
        
        this.data1= data.data;
        console.log(data);
    });
    return await modal.present();
    
  }


  async modals2(response){
    const modal = await this.modalController.create({
      component:  PointsModalPage,
      cssClass: 'my-custom-class',
      componentProps: {
        response: response,
        'model_title': "Turtle",
        'image_no':'2',
        'pre_points' : this.data2
      }
    });

    modal.onDidDismiss()
    .then((data) => {
      
      this.data2= data.data;
      // const user = data['data']; // Here's your selected user!
      console.log(data);
  });
    
    return await modal.present();
    
  }

  async modals3(response){
    const modal = await this.modalController.create({
      component:  PointsModalPage,
      cssClass: 'my-custom-class',
      componentProps: {
        response: response,
        'model_title': "Rabbit",
        'image_no':'3',
        'pre_points' : this.data3
      }
    });

    modal.onDidDismiss()
    .then((data) => {
      
      this.data3= data.data;
      // const user = data['data']; // Here's your selected user!
      console.log(data);
  });
    
    return await modal.present();
    
  }
  async modals4(response){
    const modal = await this.modalController.create({
      component:  PointsModalPage,
      cssClass: 'my-custom-class',
      componentProps: {
        response: response,
        'model_title': "Lion",
        'image_no':'4',
        'pre_points' : this.data4
      }
    });

    modal.onDidDismiss()
    .then((data) => {
      
      this.data4= data.data;
      // const user = data['data']; // Here's your selected user!
      console.log(data);
  });
    
    return await modal.present();
    
  }
  async modals5(response){
    const modal = await this.modalController.create({
      component:  PointsModalPage,
      cssClass: 'my-custom-class',
      componentProps: {
        response: response,
        'model_title': "Car",
        'image_no':'5',
        'pre_points' : this.data5
      }
    });

    modal.onDidDismiss()
    .then((data) => {
      
      this.data5= data.data;
      // const user = data['data']; // Here's your selected user!
      console.log(data);
  });
    
    return await modal.present();
    
  }
  async modals6(response){
    const modal = await this.modalController.create({
      component:  PointsModalPage,
      cssClass: 'my-custom-class',
      componentProps: {
        response: response,
        'model_title': "Aeroplane",
        'image_no':'6',
        'pre_points' : this.data6
      }
    });

    modal.onDidDismiss()
    .then((data) => {
      
      this.data6= data.data;
      // const user = data['data']; // Here's your selected user!
      console.log(data);
  });
    
    return await modal.present();
    
  }

  async modals7(response){
    const modal = await this.modalController.create({
      component:  PointsModalPage,
      cssClass: 'my-custom-class',
      componentProps: {
        response: response,
        'model_title': "Ship",
        'image_no':'7',
        'pre_points' : this.data7
      }
    });

    modal.onDidDismiss()
    .then((data) => {
      
      this.data7= data.data;
      // const user = data['data']; // Here's your selected user!
      console.log(data);
  });
    
    return await modal.present();
    
  }

  async modals8(response){
    const modal = await this.modalController.create({
      component:  PointsModalPage,
      cssClass: 'my-custom-class',
      componentProps: {
        response: response,
        'model_title': "Tree",
        'image_no':'8',
        'pre_points' : this.data8
      }
    });

    modal.onDidDismiss()
    .then((data) => {
      
      this.data8= data.data;
      // const user = data['data']; // Here's your selected user!
      console.log(data);
  });
    
    return await modal.present();
    
  }
  async modals9(response){
    const modal = await this.modalController.create({
      component:  PointsModalPage,
      cssClass: 'my-custom-class',
      componentProps: {
        response: response,
        'model_title': "Sun",
        'image_no':'9',
        'pre_points' : this.data9
      }
    });

    modal.onDidDismiss()
    .then((data) => {
      
      this.data9= data.data;
      // const user = data['data']; // Here's your selected user!
      console.log(data);
  });
    
    return await modal.present();
    
  }

  async modals10(response){
    const modal = await this.modalController.create({
      component:  PointsModalPage,
      cssClass: 'my-custom-class',
      componentProps: {
        response: response,
        'model_title': "Banana",
        'image_no':'10',
        'pre_points' : this.data10
      }
    });

    modal.onDidDismiss()
    .then((data) => {
      
      this.data10= data.data;
      // const user = data['data']; // Here's your selected user!
      console.log(data);
  });
    
    return await modal.present();
    
  }

  async modals11(response){
    const modal = await this.modalController.create({
      component:  PointsModalPage,
      cssClass: 'my-custom-class',
      componentProps: {
        response: response,
        'model_title': "Jackpot",
        'image_no':'11',
        'pre_points' : this.data11
      }
    });

    modal.onDidDismiss()
    .then((data) => {
      
      this.data11 = data.data;
      // const user = data['data']; // Here's your selected user!
      console.log(data);
  });
    
    return await modal.present();
    
  }



  

  get fran_id(){
    return this.game_points.get('fran_id');
  }

  get gameid(){
    return this.game_points.get('gameid');
  }

  get img_1(){
    return this.game_points.get('img_1');
  }

  get img_2(){
    return this.game_points.get('img_2');
  }

  get img_3(){
    return this.game_points.get('img_3');
  }

  get img_4(){
    return this.game_points.get('img_4');
  }

  get img_5(){
    return this.game_points.get('img_5');
  }

  get img_6(){
    return this.game_points.get('img_6');
  }

  get img_7(){
    return this.game_points.get('img_7');
  }

  get img_8(){
    return this.game_points.get('img_8');
  }

  get img_9(){
    return this.game_points.get('img_9');
  }

  get img_10(){
    return this.game_points.get('img_10');
  }

  get img_11(){
    return this.game_points.get('img_11');
  }

  // get img_0(){
  //   return this.game_ponts.get('img_0');
  // }


  async Submit_points(){
    
    if(this.game_points.value.total > 0){
      const loading = await this.loadingController.create();
      await loading.present();
      (await this.auth.submit_point_data(this.game_points.value)).subscribe(
        async (res) =>{
          await loading.dismiss();
          const alert = await this.alertCtrl.create({
            header:'Success',
            mode:'ios',
            message: `<img src="../../../assets/img/success.png" class="alert-success"><br><br><strong>Points Submit Successful</strong>`,
            buttons:[
              {
                text: 'OK',
                handler: () => {

                  location.reload();
                  // this.navCtrl.navigateRoot('/tabs-menu/newgame');
                }
              }],
          });
          await alert.present();
        },async (err) =>{
          await loading.dismiss();
          const alert =  this.alertCtrl.create({
            // cssClass: 'alert-warning',
            header:'warning',
            mode:'ios',
            message: err.error.message,
            buttons:[
              {
                text: 'OK',
                handler: () => {
                  location.reload();
                  // this.ionViewWillEnter();
                  // this.navCtrl.navigateRoot('/tabs-menu/newgame');
                }
              }],
          });
           (await alert).present();
        }
      )
    }else{
      this.router.navigateByUrl('/tabs-menu/newgame', { replaceUrl: true });
      const alert = await this.alertCtrl.create({
        cssClass: 'alert-danger',
        header: 'Warning',
        mode:'ios',
        message: `<img src="../../../assets/img/warning.png" class="alert-warning"><br><br><strong>Enter At least one value.</strong>`,
        buttons: ['Cancel'],        
      });
  
      await alert.present();
    }  
  }
}
