import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

import { AuthenticationService} from 'src/app/services/authentication.service';
import { UserService } from '../../services/user.service'

import { ModalController } from '@ionic/angular';
import { Game } from '../../interfaces/game';

import{ NotificationDetailsPage } from '../notification-details/notification-details.page'
import { HistoryDetailsPage } from '../history-details/history-details.page'
//import { Moment } from 'moment';
import * as moment from 'moment';

@Component({
  selector: 'app-history',
  templateUrl: './history.page.html',
  styleUrls: ['./history.page.scss'],
})
export class HistoryPage implements OnInit {


  
  private dateYesterday: Date = new Date();
  
  start_date1:any;
  end_date1:any;
  dateRang: FormGroup;

  images:any=[];

  todays:Game;
  yesterdays:Game;
  rangs: any;
  show = 'today';
  loop:any=[];
  moment: any;
  // let dte = new Date();
  // dte.setDate(dte.getDate() - 1);
  //currentdate: Date;


  constructor(
    private formBuilder: FormBuilder,
    private router: Router, 
    public modalController: ModalController,
    private authService: AuthenticationService,
    private userService: UserService,
    ) { }

  async ngOnInit() {
    //  console.log(this.todays);
    this.dateRang = this.formBuilder.group({         
      start_date:['',[Validators.required]],
      end_date:['',[Validators.required]],

    });
   

    

    
      
  }

  async ionViewWillEnter(){
    
    let today ={                            //create an object and assign value and pass it 
      dte :(moment(new Date()).format("YYYY-MM-DD"))
   };

   let yesterday ={                            //create an object and assign value and pass it 
     dateYesterday : new Date(this.dateYesterday.setDate(this.dateYesterday.getDate() - 1)),
      date : moment( this.dateYesterday).format("YYYY-MM-DD")
     };
    (await this.authService.today_game_history(today)).subscribe(response =>{
      this.todays = response
      //console.log(response)
      });    

      (await this.authService.yesterday_game_history(yesterday)).subscribe(response =>{
        this.yesterdays = response

    });    
  }

  

  get start_date(){
    return this.dateRang.get('start_date');
  }

  get end_date(){
    return this.dateRang.get('end_date');
  }

  segmentChanged(ev: any) {
    //console.log( ev.detail.value);
    this.show = ev.detail.value;
  }


  async submitdate(){

   
    let start_date1 =  moment(this.dateRang.value.start_date).format("YYYY-MM-DD");
    let end_date1 = moment(this.dateRang.value.end_date).format("YYYY-MM-DD");

     (await this.authService.date_history({start_date1, end_date1})).subscribe(response =>{
       this.rangs = response
       console.log(response);
     })

    
  }

  async openModal(response) {
    const modal = await this.modalController.create({
      component: HistoryDetailsPage,
      componentProps: { response: response }
     // componentProps: { game_id: response.game_id, winning_id:response.winning_id }
      //console.log();
      
    });
    return await modal.present();
  }



}