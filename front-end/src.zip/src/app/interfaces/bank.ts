export interface Bank{
    fran_id:any;
    account_name: any;
    account_no: any;
    bank_name: any;
    ifsc_code: any;
    branch_name: any;
    account_type:any;
    bank_city:any;
    token:any;
  }