export interface Notifications{
id: any;
date_time: any;
from: any;
to: any;
subject: any;
message: any;
is_read: any;
to_all:any;
}