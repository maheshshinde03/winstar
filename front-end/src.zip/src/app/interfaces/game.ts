export interface Game{
    game_id: any;   
	date_time : any;   
	fran_id:any;
	token:any;
	winning_id: any;    
	winning_amount: any;    
	game_amount: any;    
	myDate:any; 
	franchise_id: any; 
	img_1 : any;   
	img_2 : any;   
	img_3 : any;   
	img_4 : any;   
	img_5 : any;  
	img_6 : any;  
	img_7 : any;  
	img_8 : any;   
	img_9 : any;   
	img_10 : any; 
    img_11 : any; 
	img_0:any;

	winning_number:any;
	total_winning_amount:any;
	game_amount_placed:any;

	img_1_amount:any;
	img_2_amount:any;
	img_3_amount:any;
	img_4_amount:any;
	img_5_amount:any;
	img_6_amount:any;
	img_7_amount:any;
	img_8_amount:any;
	img_9_amount:any;
	img_10_amount:any;
	img_0_amount:any;

	fran_opening_game_deposit:any;
	fran_game_placed_amount:any;
	fran_commission_rate:any;
	fran_commission_earned:any;
	fran_winning_amount:any;
	fran_credit_deduction:any;
	fran_closing_game_deposit:any;
}