export interface User{
    fran_id:number;
    fran_userid:any;

    id:number;
    franchise_id:any;
    password:any;
    token:any;
    business_name: any;
    first_name:any;
    last_name:any;   
    mobile: any;
    alt_mobile:any;
    email:any;
    business_category:any;
    business_address:any;
    city:any;
    pin_code:any;
    landmark:any;

    fran_total_deposit:any;
    fran_fixed_deposit:any;
    fran_setup_charges:any;
    fran_game_deposit:any;
    fran_commission_rate:any;
   
  }